#pragma once

#include <tt_algo_sdk/core.hpp>
#include <tt_algo_sdk/types.hpp>

#include <string>


class MarketMaker : public tt_algo_sdk::AlgoBase {

  public:

    // Constructor
    MarketMaker ();

    // Destructor
    virtual ~MarketMaker() noexcept;

    // The OnStartAlgo() event handler is called when an algo instance is started.
    tt_algo_sdk::error_code OnStartAlgo (tt_algo_sdk::AlgoParameters& request_params) override;

    // The OnUpdateAlgo() event handler is called when an algo instance is updated.
    tt_algo_sdk::error_code OnUpdateAlgo (tt_algo_sdk::AlgoParameters& request_params) override;

    // The OnResumeAlgo() event handler is called when a paused algo instance is resumed.
    tt_algo_sdk::error_code OnResumeAlgo (tt_algo_sdk::AlgoParameters& resultant_params) override;

    // The OnPauseAlgo() event handler is called when an algo instance is paused.
    tt_algo_sdk::error_code OnPauseAlgo (tt_algo_sdk::AlgoParameters& resultant_params) override;

    // The OnStopAlgo() event handler is called when an algo instance is stopped.
    tt_algo_sdk::error_code OnStopAlgo (tt_algo_sdk::AlgoParameters& resultant_params) override;

    // The OnScheduledEvent() event handler is called when a scheduled event is ready to run.
    void OnScheduledEvent (unsigned int event_id, void* event_user_data) override;

  private:

    // This is the user-defined callback function that will be invoked when a
    // price update is received.
    void PriceUpdateCallback (const tt_algo_sdk::price_snap* price_snap,
	tt_algo_sdk::interests inters, const int instr_id, const tt_algo_sdk::AlgoInstrument& algo_instrument);

    void PriceUpdateCallbackUnder (const tt_algo_sdk::price_snap* price_snap,
    tt_algo_sdk::interests inters, const tt_algo_sdk::AlgoInstrument& algo_instrument);
    
    // This is the user-defined callback function that will be invoked when a
    // price error is received.
    void PriceErrorCallback (const std::string& error,
    const tt_algo_sdk::AlgoInstrument& algo_instrument);

    void WorkBid (const tt_algo_sdk::AlgoInstrument& algo_instrument, const int id, double bid_price);
    void WorkAsk (const tt_algo_sdk::AlgoInstrument& algo_instrument, const int id, double bid_price);

    void Work (std::shared_ptr<tt_algo_sdk::AlgoOrder>&    order,
               tt_algo_sdk::LimitOrderParameters*          order_param,
               tt_algo_sdk::AlgoOrderManager*              order_manager,
               int                                         instr_id,
               double                                      new_price,
               int                                         new_qty);

    // This is the user-defined callback function that will be invoked when a
    // an order update / fill are received.
    void OrderEventCallback (unsigned int request_id, 
                             const tt_algo_sdk::AlgoOrderEvent& order_event, 
                             bool is_bid, 
                             bool is_call, 
                             const int id,
                             const tt_algo_sdk::AlgoOrder& order);

    void DeltaHedge (const int qty);

    bool ExceedMaxDelta();

    bool ExceedMaxVega();

    double CalculateVWap(const tt_algo_sdk::price_snap* price_snap, int instr_id);

    double CalculateMidMarket(const tt_algo_sdk::price_snap* price_snap);

    double CalcOverallVega();

    double CalcOverallDelta();

    double norm_pdf(const double& x);

    double norm_cdf(const double& x);

    double d_j(const int& j, const double& S, const double& K, 
               const double& r, const double& v, const double& T);

    double call_price(const double& S, const double& K, const double& r, 
                      const double& v, const double& T);

    double put_price(const double& S, const double& K, const double& r, 
                     const double& v, const double& T);

    double call_vega(double S, double K, double r, double v, double T);

    double call_vol(double call_pr, double S, double K, double r, double T);
    
    double put_vega(double S, double K, double r, double v, double T);

    double put_vol(double put_pr, double S, double K, double r, double T);

    double put_parity(double callprice, double S, double X, double r, double T);

    double call_parity(double putprice, double S, double X, double r, double T);

    double slope(double strikes[], double vol[], int size);    

    double call_delta(double S, double K, double r, double v, double T);

    double put_delta(double S, double K, double r, double v, double T);

    double vega_vol_line_shift(double put_bids[], double put_spreads[], 
                                   double strikes[], double vega_position, 
                                   double vega_limit, double S, double r, 
                                   double T, int size);

    double delta_adjusted_fair_future();

    int GetLinRegs(int n, const double x[], const double y[], double* m, double* b);

    double StrikeToVol(const double strike, bool is_call);

    void BuildVolCurve();

    void SetUpManagers();

    void QuoteLogic();

    bool isFilled();

    //  member variables
    tt_algo_sdk::AlgoInstrument                     m_instr_arr[14];
    tt_algo_sdk::AlgoInstrument                     m_instr_underlying;

    tt_algo_sdk::LimitOrderParameters*              m_bid_params[14];
    tt_algo_sdk::LimitOrderParameters*              m_ask_params[14];
    tt_algo_sdk::MarketOrderParameters*             m_bid_param_under;
    tt_algo_sdk::MarketOrderParameters*             m_ask_param_under;
    tt_algo_sdk::AlgoOrderManager*                  m_bid_managers[14];
    tt_algo_sdk::AlgoOrderManager*                  m_ask_managers[14];
    tt_algo_sdk::AlgoOrderManager*                  m_delta_hedger;
    std::shared_ptr<tt_algo_sdk::AlgoOrder>         m_bids[14];
    std::shared_ptr<tt_algo_sdk::AlgoOrder>         m_asks[14];

    // Vars set during startAlgo
    double                                          m_mC;
    double                                          m_bC;
    double                                          m_mP;
    double                                          m_bP;   
    double                                          m_interest;
    unsigned long long                              m_account_id;
    int                                             m_max_qty;
    int                                             m_spread_mult;
    double                                          m_max_delta;
    double                                          m_max_vega;
    double                                          m_price_to_vol[14];
    int                                             m_num_strikes;
    double                                          m_strikes[14];
    int                                             m_net_positions[14];
    int                                             m_bid_qty[14];
    int                                             m_ask_qty[14];
    double                                          m_delta;
    double                                          m_vega;
    double                                          m_theta;
    bool                                            m_running;
    //int                                             m_net_position;
    //double                                          m_vwap;

    // Vars calculated during price update 
    double                                          m_best_bids[14];
    double                                          m_hard_bids[14];
    double                                          m_spreads[14];
    double                                          m_hard_spreads[14];
    double                                          m_vwap_arr[14];
    int                                             m_min_size[14];
    
    // Vars calculated during underlying price upd.
    double                                          m_theo_prices[14];
    double                                          m_price_underlying;
    double                                          m_best_bid_under;
    double                                          m_best_ask_under;

    // Vars calculated while hedging
    int                                             m_position_under;
                                      
};