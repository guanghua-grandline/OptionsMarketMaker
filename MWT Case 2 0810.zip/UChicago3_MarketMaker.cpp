#define _USE_MATH_DEFINES

#include <tt_algo_sdk/algo_logger.hpp>
#include "UChicago3_MarketMaker.hpp"
#include "log.hpp"

#include <math.h>
#include <memory>
#include <sstream>
#include <algorithm>

using namespace tt_algo_sdk;

extern "C"
{
    //
    // This function returns an instance of the algo.
    // It is required for all algos written using TT Algo SDK.
    //

    AlgoBase* CreateAlgoInstance ()
    {
        return new MarketMaker();
    }
}

//
// Constructor: Initialize all member variables
//

MarketMaker::MarketMaker ()
    : AlgoBase() 
    //, m_bid_manager(nullptr)
    //, m_ask_manager(nullptr)
    , m_mC(0)
    , m_bC(0)
    , m_mP(0)
    , m_bP(0)
    , m_delta_hedger(nullptr)
    , m_max_qty(0)
    , m_spread_mult(1)
    , m_delta(0)
    , m_vega(0)
    , m_max_delta(10)
    , m_max_vega(10000)
    //, m_bid_position(0)
    //, m_ask_position(0)
    //, m_net_position(0)
    //, m_max_position(0)
    //, m_vwap(Q_NAN)
    , m_running(false)
    , m_position_under(0)
{}


//
// Destructor
//

MarketMaker::~MarketMaker ()
{
    for (int i = 0; i < (m_num_strikes * 2); i++) {
        if (m_bid_params[i]) delete m_bid_params[i];
        if (m_ask_params[i]) delete m_ask_params[i];
        if (m_bid_managers[i]) delete m_bid_managers[i];
        if (m_ask_managers[i]) delete m_ask_managers[i];
    }

    if (m_delta_hedger) delete m_delta_hedger;
}

//
// The OnStartAlgo() event handler is called when an algo instance is started.
//

error_code
MarketMaker::OnStartAlgo (AlgoParameters& request_params)
{
    MY_ILOG("*** Inside MarketMaker::OnStartAlgo");

    if (request_params.HasCustomParam("account")) {
        m_account_id = std::stoull(request_params.GetCustomParam<std::string>("account"));
        MY_ILOG("account = %llu", m_account_id);
    } else {
        MY_ELOG("Account was not provided.  Failing algo.");

        // send a message to the TTW Audit Trail
        request_params.SetMessage("ERROR: Account parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("max_qty")) {
        m_max_qty = request_params.GetCustomParam<int>("max_qty");
        MY_ILOG("max_qty = %d", m_max_qty);
    } else {
        MY_ELOG("max_qty was not provided.  Failing algo.");

        // send a message to the TTW Audit Trail
        request_params.SetMessage("ERROR: qty parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("spread_width")) {
        m_spread_mult = request_params.GetCustomParam<int>("spread_width");
        MY_ILOG("spread_width = %d", m_spread_mult);
    } else {
        MY_ELOG("spread_width was not provided.  Failing algo.");

        request_params.SetMessage("ERROR: spread_width parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("max_d_position")) {
        m_max_delta = request_params.GetCustomParam<double>("max_d_position");
        MY_ILOG("max_delta = %d", m_max_delta);
    } else {
        MY_ELOG("max_delta was not provided.  Failing algo.");

        request_params.SetMessage("ERROR: max_d_position parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("max_v_position")) {
        m_max_vega = request_params.GetCustomParam<double>("max_v_position");
        MY_ILOG("max_vega = %d", m_max_vega);
    } else {
        MY_ELOG("max_vega was not provided.  Failing algo.");

        request_params.SetMessage("ERROR: max_v_position parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("theta")) {
        m_theta = request_params.GetCustomParam<double>("theta");
        MY_ILOG("theta = %d", m_theta);
    } else {
        MY_ELOG("theta was not provided.  Failing algo.");

        request_params.SetMessage("ERROR: theta parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("interest_rate")) {
        m_interest = request_params.GetCustomParam<double>("interest_rate");
        MY_ILOG("interest_rate = %d", m_interest);
    } else {
        MY_ELOG("interest rate was not provided.  Failing algo.");

        request_params.SetMessage("ERROR: interest parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }
   
    m_delta_hedger = new AlgoOrderManager(this, nullptr); //hedge order fire and forget. NO callback.
    
    if (request_params.HasCustomParam("num_strikes")) {

        std::string temp;
        std::string temp1;
        std::string temp_name;
        bool is_call;

        m_num_strikes = request_params.GetCustomParam<int>("num_strikes");
        MY_ILOG("num_strikes = %d", m_num_strikes);
        
        // build array of strikes
        for (int i = 0; i < m_num_strikes; i++) {
            temp1 = "strike_" + (std::to_string(i + 1));
            m_strikes[2 * i] = request_params.GetCustomParam<double>(temp1);
            m_strikes[(2 * i) + 1] = m_strikes[2 * i];
        }

        MY_ILOG("Accessing instruments: \n");
        // Create array of instruments and order managers
        SetUpManagers();
        for (int i = 0; i < (m_num_strikes * 2); i++) { 
            // Distinguish between call and put
            if (i % 2 == 0) {
                temp = "C";
                is_call = true;
            } else { 
                temp = "P";
                is_call = false;
            }
            m_bid_qty[i] = 0;
            m_ask_qty[i] = 0;
            m_net_positions[i] = 0;

            try {
                m_bid_params[i] = new LimitOrderParameters(m_account_id, time_in_force::DAY, side::BUY, NAN, m_max_qty);
                m_ask_params[i] = new LimitOrderParameters(m_account_id, time_in_force::DAY, side::SELL, NAN, m_max_qty);
            }
            catch (const std::runtime_error& e) {
                std::string error_string {"ERROR: LimitOrderParameters initialization failed -> ", e.what()};
                request_params.SetMessage(error_string);
                this->SetAlgoParameters(request_params);

                return error_code::FAILURE;
            }

            temp_name = "instr_id_" + temp + (std::to_string(i+1));
            if (request_params.HasCustomParam(temp_name)) {
                std::string instr_id = request_params.GetCustomParam<std::string>(temp_name);
                MY_ILOG("Instrument ID = %llu", std::stoull(instr_id));

                try {
                    MY_ILOG("Attempt to look up instrument...");
                    m_instr_arr[i] = AlgoInstrument(this, std::stoull(instr_id));
                }
                catch (const std::runtime_error& e) {
                    std::string error_string {"ERROR: Instrument not found -> ", e.what()};
                    MY_ELOG(error_string);

                    // send a message to the TTW Audit Trail
                    request_params.SetMessage(error_string);
                    this->SetAlgoParameters(request_params);

                    return error_code::FAILURE;
                }
                MY_ILOG("Instrument found : %s", m_instr_arr[i].GetName());

            } else {
                MY_ELOG("Instrument ID for " + temp_name + " was not provided.  Failing algo.");

                // send a message to the TTW Audit Trail
                request_params.SetMessage("ERROR: Instrument parameter not set");
                this->SetAlgoParameters(request_params);

                return error_code::PARAM_NOT_SET;
            }
        } 
    } else {
        MY_ELOG("num_strikes or strike prices were not provided.  Failing algo.");

        // send a message to the TTW Audit Trail
        request_params.SetMessage("ERROR: num_strikes parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    if (request_params.HasCustomParam("instr_underlying")) {
        std::string instr_id = request_params.GetCustomParam<std::string>("instr_underlying");
        MY_ILOG("Instrument ID = %llu", std::stoull(instr_id));

        try {
            MY_ILOG("Attempt to look up instrument...");
            m_instr_underlying = AlgoInstrument(this, std::stoull(instr_id));
        }
        catch (const std::runtime_error& e) {
            std::string error_string {"ERROR: Instrument not found -> ", e.what()};
            MY_ELOG(error_string);

            // send a message to the TTW Audit Trail
            request_params.SetMessage(error_string);
            this->SetAlgoParameters(request_params);

            return error_code::FAILURE;
        }
        MY_ILOG("Instrument found : %s", m_instr_underlying.GetName());

        // register to listen to specific price fields
        auto price_interests = interests::BID0 | interests::ASK0;

        MY_ILOG("Attempt to open a price subscription...");
        if (!m_instr_underlying.OpenPriceSubscription(
                [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                    this->PriceUpdateCallbackUnder(price_snap, inters, algo_instrument);
                },
                [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                        this->PriceErrorCallback(error, algo_instrument);
                },
                price_interests))
        {
            MY_ELOG("Price subscription failed.  Failing algo.");

            // send a message to the TTW Audit Trail
            request_params.SetMessage("ERROR: Price subscription failed");
            this->SetAlgoParameters(request_params);

            return error_code::FAILURE;
        }
    } else {
        MY_ELOG("Instrument ID for instr_underlying was not provided.  Failing algo.");

        // send a message to the TTW Audit Trail
        request_params.SetMessage("ERROR: Instrument parameter not set");
        this->SetAlgoParameters(request_params);

        return error_code::PARAM_NOT_SET;
    }

    m_running = true;

    return error_code::NONE;
}

//
// The OnUpdateAlgo() event handler is called when an algo instance is updated.
//

error_code
MarketMaker::OnUpdateAlgo (AlgoParameters& request_params)
{
    MY_ILOG( "*** Inside MarketMaker::OnUpdateAlgo");

    /*
    if (request_params.HasCustomParam("command_from_excel"))
    {
        MY_ILOG("OnUpdateAlgo command_from_excel=%s",
                request_params.GetCustomParam<std::string>("command_from_excel"));
    }

    if (request_params.HasCustomParam("max_d_position"))
    {
        int max_position = request_params.GetCustomParam<int>("max_position");
        if (m_max_position != max_position)
        {
            MY_ILOG("New max_position: %d", max_position);
            m_max_position = max_position;
            if (ExceedMaxPosition())
            {
                std::string msg = "New max_position="
                                   + std::to_string(m_max_position)
                                   +" ask position="
                                   + std::to_string(m_ask_position)
                                   +" bid position="
                                   + std::to_string(m_bid_position);
                MY_ELOG(msg);
                this->Stop();//this->Stop(msg);
            }
            return error_code::NONE;
        }
    }


    bool need_update = false;
    if (request_params.HasCustomParam("spread_width"))
    {
        int spread_width = request_params.GetCustomParam<int>("spread_width");
        if (m_spread_width != spread_width)
        {
            MY_ILOG("New spread_width: %d", spread_width);
            m_spread_width = spread_width;
            need_update = true;
        }
    }

    if (request_params.HasCustomParam("qty"))
    {
        int qty = request_params.GetCustomParam<int>("qty");
        if (m_max_qty != qty)
        {
            MY_ILOG("New qty: %d", qty);
            m_bid_qty += (qty-m_max_qty); //apply delta
            m_ask_qty += (qty-m_max_qty); //apply delta
            m_max_qty = qty;
            need_update = true;
        }
    }

    if (need_update && this->GetSyntheticStatus() == synthetic_status::WORKING)
    {
        WorkBid();
        WorkAsk();
    }
    */
    return error_code::NONE;
}

//
// The OnResumeAlgo() event handler is called when a paused algo instance is resumed.
//

error_code
MarketMaker::OnResumeAlgo (AlgoParameters& resultant_params)
{
    MY_ILOG( "*** Inside MarketMaker::OnResumeAlgo");
    m_running = true;
    CalcOverallDelta();
    CalcOverallVega();
    QuoteLogic();
    return error_code::NONE;
}

//
// The OnPauseAlgo() event handler is called when an algo instance is paused.
//

error_code
MarketMaker::OnPauseAlgo (AlgoParameters& resultant_params)
{
    MY_ILOG("*** Inside MarketMaker::OnPauseAlgo");
    m_running = false;
    /*
    if (m_bid)
    {
        m_bid_param->SetOrderQuantity(0);
        m_bid->ChangeQuantity(0);
    }
    if (m_ask)
    {
        m_ask_param->SetOrderQuantity(0);
        m_ask->ChangeQuantity(0);
    }
    */
    return error_code::NONE;
}

//
// The OnStopAlgo() event handler is called when an algo instance is stopped.
//

error_code
MarketMaker::OnStopAlgo (AlgoParameters& resultant_params)
{
    MY_ILOG( "*** Inside MarketMaker::OnStopAlgo");
    m_running = false;

    for (int i = 0; i < (m_num_strikes*2); i++) {
        if (m_bids[i]) m_bids[i]->Delete();
        if (m_asks[i]) m_asks[i]->Delete();
        m_instr_arr[i].ClosePriceSubscription();
    }
    m_instr_underlying.ClosePriceSubscription();

    //GlobalFills::Instance().UnRegisterCallback(this);
    return error_code::NONE;
}

//
// The OnScheduledEvent() event handler is called when a scheduled event is ready to run.
//

void
MarketMaker::OnScheduledEvent (unsigned int event_id, void* event_user_data)
{
    MY_ILOG( "*** Inside SubmitSingleOrder::OnScheduledEvent");
}



//
// This is the user-defined callback function that will be invoked when a
// price update is received.
//

void 
MarketMaker::PriceUpdateCallback (const price_snap* price_snap, 
                                  interests inters, 
                                  const int instr_id,
	                              const AlgoInstrument& algo_instrument)
{
    if (price_snap != nullptr)
    {
        double vwap = CalculateVWap(price_snap, instr_id);
        if (isnan(vwap)) {
            return; //incomplete book
        }

        if (isnan(m_vwap_arr[instr_id]) || (m_vwap_arr[instr_id] != vwap)) {
            m_vwap_arr[instr_id] = vwap;

        } else {
            return; // vwap does not move
        }

        if (this->GetSyntheticStatus() == synthetic_status::WORKING) {
            QuoteLogic();
        }
    }
}

void 
MarketMaker::PriceUpdateCallbackUnder(const price_snap* price_snap, const interests inters,
                                      const AlgoInstrument& algo_instrument) 
{
    if ((price_snap->bids.levels[0].price == m_best_bid_under) && 
        (price_snap->asks.levels[0].price == m_best_ask_under)) return;
    if (price_snap != nullptr) {
        m_price_underlying = CalculateMidMarket(price_snap);
        QuoteLogic();
    }
}

//
// This is the user-defined callback function that will be invoked when a
// price error is received.
//
void
MarketMaker::PriceErrorCallback (const std::string& error, const AlgoInstrument& algo_instrument)
{
    MY_ELOG("*** Inside MarketMaker::PriceErrorCallback");
    MY_ELOG("ERROR: %s", error);
    //this->Stop(); //this->Stop(error);
}

void 
MarketMaker::QuoteLogic() 
{
    CalcOverallVega();
    CalcOverallDelta();
    BuildVolCurve();
    double bid_to_quote, offer_to_quote, b_a3, b_a1, hard_bid, hard_offer, best_bid, best_offer, mmkt, hb_a, rb_a, theo;
    
    for (int id = 0; id < (m_num_strikes * 2); id++) {
        theo = m_theo_prices[id];
        rb_a = m_spreads[id];
        hb_a = m_hard_spreads[id];
        hard_bid = m_hard_bids[id];
        hard_offer = hard_bid + hb_a;
        best_bid = m_best_bids[id];
        best_offer = best_bid + rb_a;
        b_a3 = hard_bid + 0.875 * hb_a;
        b_a1 = hard_bid + 0.125 * hb_a;
        mmkt = m_vwap_arr[id];

        if(theo>hard_offer)
        {
            bid_to_quote = m_instr_arr[id].TickPriceUp(hard_bid,1);
            offer_to_quote = bid_to_quote + (1.5 * rb_a);
        }
        else if(theo<hard_bid)
        {
            offer_to_quote = m_instr_arr[id].TickPriceDown(hard_offer,1);
            bid_to_quote = offer_to_quote - (1.5 * rb_a);
        }
        else if(theo<b_a3 && theo>b_a1)
        {
            offer_to_quote = hard_offer;
            bid_to_quote = hard_bid;
        }
        else if(theo>b_a3)
        {
            bid_to_quote = m_instr_arr[id].TickPriceUp(hard_bid,1);
            offer_to_quote = hard_offer;
        }
        else if(theo<b_a1)
        {
            offer_to_quote = m_instr_arr[id].TickPriceDown(hard_offer,1);
            bid_to_quote = hard_bid;
        }
        if(bid_to_quote > mmkt) {
            bid_to_quote = mmkt;
        } 
        if(offer_to_quote < mmkt) {
            offer_to_quote = mmkt;
        }
        while(offer_to_quote - bid_to_quote > 1.5*rb_a)
        {
            if(offer_to_quote - theo > theo - bid_to_quote)
            {
                offer_to_quote = m_instr_arr[id].TickPriceDown(offer_to_quote,1);
            }
            else
            {
                bid_to_quote = m_instr_arr[id].TickPriceUp(bid_to_quote,1);
            }
        }
        int temp = id;
        WorkBid(m_instr_arr[id], temp, bid_to_quote);
        int temp1 = id;
        WorkAsk(m_instr_arr[id], temp, offer_to_quote);
    }
}

void
MarketMaker::WorkBid (const AlgoInstrument& algo_instrument, const int id, double bid_price)
{

    m_bid_qty[id] = std::max((int) (0.3*(m_max_vega-m_vega) / m_max_vega * m_max_qty), 1);

    MY_ILOG("WorkBid: p=%f q=%d m_vwap=%f", bid_price, m_bid_qty[id], m_vwap_arr[id]);
    Work(m_bids[id], m_bid_params[id], m_bid_managers[id], id, bid_price, m_bid_qty[id]);
}

void
MarketMaker::WorkAsk (const AlgoInstrument& algo_instrument, const int id, double ask_price)
{
    m_ask_qty[id] = std::max((int) (-0.3*(m_max_vega + m_vega) / m_max_vega * m_max_qty), 1);

    MY_ILOG("WorkAsk: p=%f q=%d m_vwap=%f", ask_price, m_ask_qty[id], m_vwap_arr[id]);
    Work(m_asks[id], m_ask_params[id], m_ask_managers[id], id, ask_price, m_ask_qty[id]);
}

void
MarketMaker::Work (std::shared_ptr<AlgoOrder>&    order,
                   LimitOrderParameters*          order_param,
                   AlgoOrderManager*              order_manager,
                   int                            instr_id,
                   double                         new_price,
                   int                            new_qty)
{
    if (!m_running) return;

    auto side = order_param->GetSide() == tt_algo_sdk::side::BUY ? "Bid": "Ask";

    if (!order) {
        order_param->SetPrice(new_price);
        order_param->SetOrderQuantity(new_qty);

        auto order_tuple = order_manager->PlaceOrder(m_instr_arr[instr_id], *order_param);

        // check status with returned error code
        if (std::get<1>(order_tuple) == order_error_code::NONE) {
            order = std::make_shared<AlgoOrder>(std::move(const_cast<AlgoOrder&>(std::get<0>(order_tuple))));
            MY_ILOG("New %s %d @ %f request_id=%d", side, new_qty, new_price, std::get<2>(order_tuple));
        } else {
            std::string error_string {"Order was not sent due to error : %s", to_string(std::get<1>(order_tuple)).c_str()};
            MY_ELOG(error_string);
            //this->Stop(error_string);
            //this->Stop();
        }
    } else {
        bool p_changed = false;
        bool q_changed = false;
        if (!fp_eq(new_price, order_param->GetPrice())
            && m_instr_arr[instr_id].PriceToTicks(new_price) != m_instr_arr[instr_id].PriceToTicks(order_param->GetPrice()))
        {
            MY_ILOG("%s change p %f-->%f  ", side, order_param->GetPrice(), new_price);
            order_param->SetPrice(new_price);
            p_changed = true;
        }

        if (new_qty != order_param->GetOrderQuantity()) {
            MY_ILOG("%s change q %d-->%d ", side, order_param->GetOrderQuantity(), new_qty);
            order_param->SetOrderQuantity(new_qty);
            q_changed = true;
        }

        if (p_changed && q_changed) {
            order->ChangePriceQuantity(new_price, new_qty);
        } else if (p_changed) {
            order->ChangePrice(new_price);
        } else if (q_changed) {
            order->ChangeQuantity(new_qty);
        }
    }
}

//
// This is the user-defined callback function that will be invoked when a
// an order update / fill are received.
//
void
MarketMaker::OrderEventCallback (unsigned int request_id, 
                                 const AlgoOrderEvent& order_event, 
                                 bool is_bid, 
                                 bool is_call, 
                                 const int id,
                                 const AlgoOrder& order)
{
    MY_ILOG("*** Inside MarketMaker::OrderEventCallback");

    auto event_type = order_event.GetEventType();
    auto status = order_event.GetLastStatus();
    MY_ILOG("request_id=%d, order event=%s, order_status=%s", 
            request_id, 
            to_string(event_type),
            to_string(status));

    switch (event_type) {
        case order_event_type::STATUS: {
            switch (status) {
                case order_status::NEW: {
                    MY_ILOG("New order acknowledgement was received.");
                    break;
                }
                case order_status::FULL_FILL: {
                }
                case order_status::PARTIAL_FILL: {
                    auto fill_quantity = order_event.GetLastFillQuantity();
                    auto fill_price = order_event.GetLastFillPrice();

                    int d_hedge_qty = 1;

                    MY_ILOG("Got Fill %d @ %f, Placing %s hedge %d current vwap=%f",
                            fill_quantity,
                            fill_price,
                            (is_bid? "Sell" : "Buy"),
                            d_hedge_qty,
                            m_vwap_arr[id]);

                    //reload
                    if (is_bid) {
                        m_net_positions[id] += fill_quantity;
                        m_bid_qty[id] -= fill_quantity;
                    } else {
                        m_net_positions[id] -= fill_quantity;
                        m_ask_qty[id] -= fill_quantity;
                        
                    }
                    QuoteLogic();
                    if (ExceedMaxDelta()) {
                        DeltaHedge(d_hedge_qty);
                    }
                    break;
                }
                case order_status::REJECT: {
                    MY_ELOG("Order was rejected...idk why");
                    //this->Stop("Order rejected");
                    break;
                }
                case order_status::REPLACE: {
                    auto quantity = order_event.GetQuantity();
                    auto price = order_event.GetPrice();
                    MY_ILOG("Order was replaced: price=%f, quantity=%d", price, quantity);
                    break;
                }
                case order_status::CANCEL: {
                    MY_ILOG("Order cancelled!"); //TODO log more info
                    break;
                }
                default: {
                    break;
                }
            }
            break;
        }
        case order_event_type::REQUEST_TIMEOUT: {
            MY_ELOG("Order request timeout!");
            //this->Stop();
            break;
        }
        case order_event_type::REQUEST_FAILURE: {
            MY_ELOG("Order request failed!");
            //this->Stop();
            break;
        }
        default: {
            break;
        }
    }
}

void
MarketMaker::DeltaHedge (const int qty) 
{
    //hedge
    bool is_bid = (m_delta > 0);
    m_delta_hedger->PlaceOrder(m_instr_underlying,
                               MarketOrderParameters(m_account_id,
                                                     time_in_force::DAY,
                                                     is_bid? side::SELL : side::BUY,
                                                     qty)
                              );
    if (is_bid) {
        m_position_under -= qty;
    } else {
        m_position_under += qty;
    }
}

bool
MarketMaker::ExceedMaxDelta ()
{
    return (std::abs(m_delta) > m_max_delta);
}

bool 
MarketMaker::ExceedMaxVega ()
{
    return (std::abs(m_vega) > m_max_vega);
}

//
// Record Prices
//
double
MarketMaker::CalculateVWap (const price_snap* price_snap, int instr_id)
{
    if (m_min_size[instr_id] == 0) {
        m_min_size[instr_id] = (price_snap->bids.levels[0].quantity + 
                                price_snap->asks.levels[0].quantity) / 2;
    }

    const depth_level* best_bid = &price_snap->bids.levels[0];
    m_best_bids[instr_id] = best_bid->price;
    m_hard_bids[instr_id] = best_bid->price;
    const depth_level* best_bid1 = &price_snap->bids.levels[1];
    int bid_qty = best_bid->quantity;

    if ((best_bid->price < m_bid_params[instr_id]->GetPrice() + 0.00001) && 
        (best_bid->price > m_bid_params[instr_id]->GetPrice() - 0.00001)) // My order has join the bid or became the inside market, reduced the quantity or move down to next level
    {
        auto working = m_bid_params[instr_id]->GetOrderQuantity() - m_bid_qty[instr_id];
        if (bid_qty <= working) {
            m_hard_bids[instr_id] = best_bid1->price;
        }
    } else if (bid_qty < m_min_size[instr_id]) {
        m_hard_bids[instr_id] = best_bid1->price;
        bid_qty = best_bid1->quantity;
    }

    const depth_level* best_ask = &price_snap->asks.levels[0];
    const depth_level* best_ask1 = &price_snap->asks.levels[1];
    m_hard_spreads[instr_id] = best_ask->price - m_hard_bids[instr_id];
    int ask_qty = best_ask->quantity;
    
    if ((best_ask->price < m_ask_params[instr_id]->GetPrice() + 0.00001) &&
        (best_ask->price > m_ask_params[instr_id]->GetPrice() - 0.00001)) // My order has join the Ask or became the inside market, reduced the quantity or move down to next level
    {
        auto working = m_ask_params[instr_id]->GetOrderQuantity() - m_ask_qty[instr_id];
        if (ask_qty <= working) {
            m_hard_spreads[instr_id] = best_ask1->price - m_hard_bids[instr_id];
        }
    } else if (ask_qty < m_min_size[instr_id]) {
        m_hard_spreads[instr_id] = best_ask1->price;
        ask_qty = best_ask1->quantity;
    }
    // Sets hard bid and spread values

    m_spreads[instr_id] = price_snap->asks.levels[0].price - price_snap->bids.levels[0].price;

    MY_ILOG("Market Info: bid[0]=[%f,%d] bid[1]=[%f,%d] will use bid=[%f,%d]",
            price_snap->bids.levels[0].price,
            price_snap->bids.levels[0].quantity,
            price_snap->bids.levels[1].price,
            price_snap->bids.levels[1].quantity,
            best_bid->price,
            bid_qty);
    MY_ILOG("Market Info: ask[0]=[%f,%d] ask[1]=[%f,%d] will use ask=[%f,%d]",
            price_snap->asks.levels[0].price,
            price_snap->asks.levels[0].quantity,
            price_snap->asks.levels[1].price,
            price_snap->asks.levels[1].quantity,
            best_ask->price,
            ask_qty);

    double v_wap = (m_hard_bids[instr_id] + m_hard_spreads[instr_id]) / 2.;
    MY_ILOG("MidMarket result %f", v_wap);
    return v_wap;
}

//
// Calculate mid-market for futures
//
double
MarketMaker::CalculateMidMarket (const price_snap* price_snap) 
{
    const depth_level* best_bid = &price_snap->bids.levels[0];
    int bid_qty = best_bid->quantity;

    const depth_level* best_ask = &price_snap->asks.levels[0];
    int ask_qty = best_ask->quantity;
    // Save best bid and offer
    m_best_bid_under = best_bid->price;
    m_best_ask_under = best_ask->price;

    MY_ILOG("Underlying Market Info: bid[0]=[%f,%d], ask[0] = [%f, %d]",
            price_snap->bids.levels[0].price,
            price_snap->bids.levels[0].quantity,
            price_snap->asks.levels[0].price,
            price_snap->asks.levels[0].quantity);

    double mid = (m_best_bid_under + m_best_ask_under)/2.;
    MY_ILOG("Mid-Market result %f", mid);
    return mid;
}

double
MarketMaker::CalcOverallVega() {
    // using hard midmarket vol
    double sum_vega = 0;
    for (int i = 0; i < (m_num_strikes * 2); i++) {
        if (i % 2 == 0) {
            sum_vega += call_vega(m_price_underlying, m_strikes[i], m_interest, m_price_to_vol[i], m_theta) * m_net_positions[i];
        } else {
            sum_vega += put_vega(m_price_underlying, m_strikes[i], m_interest, m_price_to_vol[i], m_theta) * m_net_positions[i];
        }
    }
    m_vega = sum_vega;
    return sum_vega;
}

double
MarketMaker::CalcOverallDelta() {
    // using hard midmarket vol
    double sum_delta = 0;
    for (int i = 0; i < (m_num_strikes * 2); i++) {
        if (i%2 == 0) {
            sum_delta += call_delta(m_price_underlying, m_strikes[i], m_interest, m_price_to_vol[i], m_theta) * m_net_positions[i];
        } else {
            sum_delta += put_delta(m_price_underlying, m_strikes[i], m_interest, m_price_to_vol[i], m_theta) * m_net_positions[i];
        }
    }
    sum_delta += m_position_under;
    return sum_delta;
}

double 
MarketMaker::norm_pdf(const double& x) {
    return (1.0/(pow(2*M_PI,0.5)))*exp(-0.5*x*x);
}

double 
MarketMaker::norm_cdf(const double& x) {
    double k = 1.0/(1.0 + 0.2316419*x);
    double k_sum = k*(0.319381530 + k*(-0.356563782 + k*(1.781477937 + k*(-1.821255978 + 1.330274429*k))));

    if (x >= 0.0) {
        return (1.0 - (1.0/(pow(2*M_PI,0.5)))*exp(-0.5*x*x) * k_sum);
    } else {
        return 1.0 - norm_cdf(-x);
    }
}

double 
MarketMaker::d_j(const int& j, const double& S, const double& K, 
                 const double& r, const double& v, const double& T) 
{
    return (log(S/K) + (r + (pow(-1,j-1))*0.5*v*v)*T)/(v*(pow(T,0.5)));
}

double 
MarketMaker::call_price(const double& S, const double& K, const double& r, 
                        const double& v, const double& T) 
{
    return S * norm_cdf(d_j(1, S, K, r, v, T))-K*exp(-r*T) * norm_cdf(d_j(2, S, K, r, v, T));
}

double 
MarketMaker::put_price(const double& S, const double& K, const double& r, 
                       const double& v, const double& T) 
{
    return -S*norm_cdf(-d_j(1, S, K, r, v, T))+K*exp(-r*T) * norm_cdf(-d_j(2, S, K, r, v, T));
}

double 
MarketMaker::call_vega(double S, double K, double r, double v, double T)
{
    return (call_price(S,K,r,v+.00001,T)-call_price(S,K,r,v-.00001,T))/(.00002);
}

double 
MarketMaker::put_vega(double S, double K, double r, double v, double T)
{
    return (put_price(S,K,r,v+.00001,T)-put_price(S,K,r,v-.00001,T))/(.00002);
}



double 
MarketMaker::call_vol(double call_pr, double S, double K, double r, double T)
{
    double precision = .001;
    double vol = .2;
    double x_n = vol, x_n1 = vol - 1;
    while(std::abs(x_n-x_n1)>precision)
    {
        x_n = x_n1;
        x_n1 = x_n + (call_pr-call_price(S, K, r, x_n, T))/call_vega(S, K, r, x_n, T);
    }
    return x_n;
}

double 
MarketMaker::put_vol(double put_pr, double S, double K, double r, double T)
{
    double precision = .001;
    double vol = .2;
    double x_n = vol, x_n1 = vol - 1;
    while(std::abs(x_n-x_n1)>precision)
    {
        x_n = x_n1;
        x_n1 = x_n + (put_pr-put_price(S, K, r, x_n, T))/put_vega(S, K, r, x_n, T);
    }
    return x_n;
}

double 
MarketMaker::put_parity(double callprice, double S, double X, double r, double T)
{
    double putprice = callprice - S + X*exp(-r*T);
    return putprice;
}

double 
MarketMaker::call_parity(double putprice, double S, double X, double r, double T)
{
    double callprice = putprice + S - X*exp(-r*T);
    return callprice;
}

double 
MarketMaker::slope(double strikes[], double vol[], int size)
{
    return (vol[0] - vol[size-1])/(strikes[0]/strikes[size-1]);
}

double 
MarketMaker::call_delta(double S, double K, double r, double v, double T)
{
    return (call_price(S+.00001,K,r,v,T)-call_price(S-.00001,K,r,v,T))/(.00002);
}

double 
MarketMaker::put_delta(double S, double K, double r, double v, double T)
{
    return (put_price(S+.00001,K,r,v,T)-put_price(S-.00001,K,r,v,T))/(.00002);
}

double 
MarketMaker::vega_vol_line_shift(double put_bids[], double put_spreads[], double strikes[], double vega_position, double vega_limit, double S, double r, double T, int size)
//Add this number to the y-intercept of the vol line used for adjusted theos
{
    double min_spread = 999999999, bid_vol, offer_vol, spread, range_to_scale;
    for(int i=0; i<size; i++) {   
        // put_vol is just vol
        bid_vol = put_vol(put_bids[i], S, strikes[i], r, T);
        offer_vol = put_vol(put_bids[i] + put_spreads[i], S, strikes[i], r, T);
        spread = offer_vol - bid_vol;
        if(spread<min_spread) {
            min_spread = spread;
        }
    }
    range_to_scale = (min_spread / 2) / vega_limit;
    return range_to_scale * vega_position * -1;
}

double 
MarketMaker::delta_adjusted_fair_future()
{
    double adjusted, mmkt, b_a, range_to_scale;
    mmkt = (m_best_bid_under + m_best_ask_under)/2;
    b_a = m_best_ask_under - m_best_bid_under;
    range_to_scale = (b_a / 2) / m_max_delta;
    adjusted = mmkt + range_to_scale * m_delta;
    if (adjusted > m_best_ask_under)
    {
        adjusted = m_best_ask_under;
    }
    else if (adjusted < m_best_bid_under)
    {
        adjusted = m_best_bid_under;
    }
    return adjusted;
}

double
MarketMaker::StrikeToVol(const double strike, bool is_call) {
    if (is_call) {
        return (m_mC * strike + m_bC); 
    } else {
        return (m_mP * strike + m_bP);
    }
    
}

int
MarketMaker::GetLinRegs(int n, const double x[], const double y[], double* m, double* b)
{
    double   sumx = 0.0;                        /* sum of x                      */
    double   sumx2 = 0.0;                       /* sum of x**2                   */
    double   sumxy = 0.0;                       /* sum of x * y                  */
    double   sumy = 0.0;                        /* sum of y                      */
    double   sumy2 = 0.0;                       /* sum of y**2                   */

    for (int i=0; i<n; i++)   
    { 
      sumx  += x[i];       
      sumx2 += x[i] * x[i];  
      sumxy += x[i] * y[i];
      sumy  += y[i];      
      sumy2 += y[i] * y[i]; 
    } 

   double denom = (n * sumx2 - sumx*sumx);
   if (denom == 0) {
       // singular matrix. can't solve the problem.
       *m = 0;
       *b = 0;
       return 1;
   }

   *m = (n * sumxy  -  sumx * sumy) / denom;
   *b = (sumy * sumx2  -  sumx * sumxy) / denom;

   return 0; 
}

void
MarketMaker::BuildVolCurve() 
{
    int num_strikes = m_num_strikes;
    double call_vols[num_strikes];
    double call_bids[num_strikes];
    double call_spreads[num_strikes];
    double put_bids[num_strikes];
    double put_spreads[num_strikes];
    double put_vols[num_strikes];
    double strikes[num_strikes];
    double d_shift_under = delta_adjusted_fair_future();

    for (int i = 0; i < (m_num_strikes * 2); i++) {
        if (i % 2 == 0) {
            strikes[i / 2] = m_strikes[i];
            m_price_to_vol[i] = call_vol(m_vwap_arr[i], d_shift_under, m_strikes[i], m_interest, m_theta);
            call_vols[i / 2] = m_price_to_vol[i];
            call_bids[i / 2] = m_hard_bids[i];
            call_spreads[i / 2] = m_hard_spreads[i];
        } else {
            m_price_to_vol[i] = put_vol(m_vwap_arr[i], d_shift_under, m_strikes[i], m_interest, m_theta);
            put_vols[i / 2] = m_price_to_vol[i];
            put_bids[i / 2] = m_hard_bids[i];
            put_spreads[i / 2] = m_hard_spreads[i];
        }
    }

    GetLinRegs(m_num_strikes, strikes, call_vols, &m_mC, &m_bC);
    GetLinRegs(m_num_strikes, strikes, put_vols, &m_mP, &m_bP);

    m_bC += vega_vol_line_shift(call_bids, call_spreads, strikes, m_vega, m_max_vega, m_price_underlying, m_interest, m_theta, num_strikes);
    m_bP += vega_vol_line_shift(put_bids, put_spreads, strikes, m_vega, m_max_vega, m_price_underlying, m_interest, m_theta, num_strikes);
    
    for (int i = 0; i < (num_strikes * 2); i++) {
        if (i % 2 == 0) {
            m_theo_prices[i] = call_price(m_price_underlying, m_strikes[i], m_interest, StrikeToVol(m_strikes[i], true), m_theta);
        } else {
            m_theo_prices[i] = put_price(m_price_underlying, m_strikes[i], m_interest, StrikeToVol(m_strikes[i], false), m_theta);
        }
    }
}


























void
MarketMaker::SetUpManagers() {
    auto price_interests = interests::BID0 | interests::ASK0;

    if (m_num_strikes >= 3) {
        m_instr_arr[0].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 0, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_instr_arr[1].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 1, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_instr_arr[2].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 2, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_instr_arr[3].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 3, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_instr_arr[4].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 4, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_instr_arr[5].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 5, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_bid_managers[0] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 0, order);
                    }
        );

        m_ask_managers[0] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 0, order);
                    }
        ); 
        m_bid_managers[1] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 1, order);
                    }
        );

        m_ask_managers[1] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 1, order);
                    }
        ); 
        m_bid_managers[2] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 2, order);
                    }
        );

        m_ask_managers[2] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 2, order);
                    }
        ); 
        m_bid_managers[3] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 3, order);
                    }
        );

        m_ask_managers[3] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 3, order);
                    }
        ); 
        m_bid_managers[4] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 4, order);
                    }
        );

        m_ask_managers[4] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 4, order);
                    }
        ); 
        m_bid_managers[5] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 5, order);
                    }
        );

        m_ask_managers[5] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 5, order);
                    }
        ); 
    }
    if (m_num_strikes >= 5) {
        m_instr_arr[6].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 6, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);
        m_instr_arr[7].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 7, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);
        m_instr_arr[8].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 8, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);
        m_instr_arr[9].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 9, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_bid_managers[6] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 6, order);
                    }
        );

        m_ask_managers[6] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 6, order);
                    }
        ); 
        m_bid_managers[7] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 7, order);
                    }
        );

        m_ask_managers[7] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 7, order);
                    }
        ); 
        m_bid_managers[8] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 8, order);
                    }
        );

        m_ask_managers[8] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 8, order);
                    }
        ); 
        m_bid_managers[9] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 9, order);
                    }
        );

        m_ask_managers[9] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 9, order);
                    }
        ); 
    }
    if (m_num_strikes >= 7) {
        m_instr_arr[10].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 10, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);
        m_instr_arr[11].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 11, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);
        m_instr_arr[12].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 12, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);
        m_instr_arr[13].OpenPriceSubscription(
                        [this] (const price_snap* price_snap, interests inters, const AlgoInstrument& algo_instrument) {
                            this->PriceUpdateCallback(price_snap, inters, 13, algo_instrument);
                        },
                        [this] (const std::string& error, const AlgoInstrument& algo_instrument) {
                                this->PriceErrorCallback(error, algo_instrument);
                        },
                        price_interests);

        m_bid_managers[10] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 10, order);
                    }
        );

        m_ask_managers[10] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 10, order);
                    }
        ); 
        m_bid_managers[11] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 11, order);
                    }
        );

        m_ask_managers[11] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 11, order);
                    }
        ); 
        m_bid_managers[12] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, true, 12, order);
                    }
        );

        m_ask_managers[12] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, true, 12, order);
                    }
        ); 
        m_bid_managers[13] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, true, false, 13, order);
                    }
        );

        m_ask_managers[13] = new AlgoOrderManager(this,
                [this] (unsigned int request_id, const tt_algo_sdk::AlgoOrder& order,
                    const tt_algo_sdk::AlgoOrderEvent& order_event) {
                        this->OrderEventCallback(request_id, order_event, false, false, 13, order);
                    }
        ); 
    }
}